let RECEPTEK = [
  {
    receptnev: "Véres hurka májjal, vér nélkül",
    datum: "2025-12-03",
    posztolo: "Hurka Gyurka",
    leiras: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed fermentum bibendum nulla, sed condimentum mauris. Vivamus pulvinar ac tellus in consequat. Duis dui risus, rutrum vitae augue in, varius pharetra massa. Donec dui magna, pulvinar id tincidunt eget, fringilla quis diam. Sed fringilla ipsum tempus, gravida tellus eget, fermentum enim. Vestibulum rutrum ipsum ut nisi elementum, id condimentum mauris volutpat. Nam in vehicula turpis.",
    ar: 1,
    konyha: "Magyar",
    ido: 45,
    fogas: "Főétel",
    nehezseg: 1,
    preferenciak: 1,
    kepUrl: ""
  },
  {
    receptnev: "Májas hurka vérrel, máj nélkül",
    datum: "2025-12-02",
    posztolo: "Hurka Gyurka",
    leiras: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed fermentum bibendum nulla, sed condimentum mauris. Vivamus pulvinar ac tellus in consequat. Duis dui risus, rutrum vitae augue in, varius pharetra massa. Donec dui magna, pulvinar id tincidunt eget, fringilla quis diam. Sed fringilla ipsum tempus, gravida tellus eget, fermentum enim. Vestibulum rutrum ipsum ut nisi elementum, id condimentum mauris volutpat. Nam in vehicula turpis.",
    ar: 2,
    konyha: "Magyar",
    ido: 50,
    fogas: "Főétel",
    nehezseg: 2,
    preferenciak: 2,
    kepUrl: ""
  },
  {
    receptnev: "Sült kolbász",
    datum: "2011-04-21",
    posztolo: "Kolbász Kolos",
    leiras: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed fermentum bibendum nulla, sed condimentum mauris. Vivamus pulvinar ac tellus in consequat. Duis dui risus, rutrum vitae augue in, varius pharetra massa. Donec dui magna, pulvinar id tincidunt eget, fringilla quis diam. Sed fringilla ipsum tempus, gravida tellus eget, fermentum enim. Vestibulum rutrum ipsum ut nisi elementum, id condimentum mauris volutpat. Nam in vehicula turpis.",
    ar: 3,
    konyha: "Német",
    ido: 10,
    fogas: "Főétel",
    nehezseg: 3,
    preferenciak: 3,
    kepUrl: ""
  },
  {
    receptnev: "Amerikai palacsinta",
    datum: "2020-09-30",
    posztolo: "Desszert Dezső",
    leiras: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed fermentum bibendum nulla, sed condimentum mauris. Vivamus pulvinar ac tellus in consequat. Duis dui risus, rutrum vitae augue in, varius pharetra massa. Donec dui magna, pulvinar id tincidunt eget, fringilla quis diam. Sed fringilla ipsum tempus, gravida tellus eget, fermentum enim. Vestibulum rutrum ipsum ut nisi elementum, id condimentum mauris volutpat. Nam in vehicula turpis.",
    ar: 1,
    konyha: "Amerikai",
    ido: 15,
    fogas: "Desszert",
    nehezseg: 2,
    preferenciak: 4,
    kepUrl: ""
  },
  
];

let PREFERENCIAK = [
  {
    id: 1,
    asd: true,
    dsa: false,
    a: false,
    b: true
  },
  {
    id: 2,
    asd: false,
    dsa: true,
    a: true,
    b: false
  },
  {
    id: 3,
    asd: true,
    dsa: true,
    a: false,
    b: false
  },
];

export function listaz() {
  return RECEPTEK;
}

export function listazPref(){
  return PREFERENCIAK;
}

