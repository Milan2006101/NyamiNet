export default function Recipe({receptnev, datum, posztolo, leiras, ar, konyha, ido, fogas, nehezseg, preferenciak}){
    return(
        <div className="recipe">

            
            <div className="recipe1">
                <h1>{receptnev}</h1>
                <h3>Posztolva: {datum}</h3>
                <h3>Posztoló: {posztolo}</h3>
                <div className="leiras">
                    <p>{leiras}</p>
                </div>
            </div>


            <div className="recipe2">
                <nobr><h3>Ár: {ar}</h3></nobr>
                <nobr><h3>Konyha: {konyha}</h3></nobr>
                <nobr><h3>Elkészítési idő: {ido}p</h3></nobr>
                <nobr><h3>Fogás: {fogas}</h3></nobr>
                <nobr><h3>Nehézség: {nehezseg}</h3></nobr>
            </div>
            
            <div>

            </div>
        </div>
    )
}