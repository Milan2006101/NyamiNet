import { useState } from "react";
import {listaz} from "../../data.js";
import Recipes from "./recipes.jsx";
import NavbarLogin from "../navbar/navbarLogin.jsx";
import Sidebar from "./sidebar.jsx";
import Footer from "../navbar/footer.jsx";

export default function MainLogin(){
    const [receptek, setReceptek] = useState(listaz());

    return(
        <>
        <header>
            <NavbarLogin selected="fooldal"/>
        </header>
        <main>
            <Recipes receptek={receptek} setReceptek={setReceptek} />
            <Sidebar />
        </main>
        <footer>
            <Footer />
        </footer>
        </>
    )
}