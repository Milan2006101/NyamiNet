import { useState } from "react";
import {listaz} from "../../data.js";
import Recipes from "./recipes.jsx";
import NavbarLogin from "../navbar/navbarLogin.jsx";
import Sidebar from "./sidebar.jsx";
import Footer from "../navbar/footer.jsx";

export default function MainSaved(){
    const [receptek, setReceptek] = useState(listaz());

    return(
        <>
        <header>
            <NavbarLogin selected="mentett"/>
        </header>
        <main>
            <Recipes receptek={receptek} setReceptek={setReceptek} />
            <Sidebar />
        </main>
        <footer>
            <Footer />
        </footer>
        </>
    )
}