export default function Sidebar(){
    return(
        <div className="sidebar">
            <div>
                <h2 className="sideTitle">Ár:</h2>
                <div className="sideRow">
                    <button className="sideButton three x-large-font">$</button>
                    <button className="sideButton three x-large-font">$$</button>
                    <button className="sideButton three x-large-font">$$$</button>
                </div>
            </div>
            <div>
                <h2 className="sideTitle">Konyha:</h2>
                <div className="sideRow">
                    <select className="sideSelect" />
                </div>
            </div>
            <div>
                <h2 className="sideTitle">Elkészítési idő:</h2>
                <div className="sideRow">
                    <button className="sideButton">&lt; 30 perc</button>
                    <button className="sideButton">30-60 perc</button>
                    <button className="sideButton">1-3 óra</button>
                    <button className="sideButton">3 óra &lt;</button>
                </div>
            </div>
            <div>
                <h2 className="sideTitle">Étel preferenciák:</h2>
                <div className="sideRow">
                    <select className="sideSelect" />
                </div>
            </div>
            <div>
                <h2 className="sideTitle">Dátum:</h2>
                <div className="sideRow">
                    <select className="sideSelect" />
                </div>
            </div>
            <div>
                <h2 className="sideTitle">Fogás:</h2>
                <div className="sideRow">
                    <select className="sideSelect" />
                </div>
            </div>
            <div>
                <h2 className="sideTitle">Nehézség:</h2>
                <div className="sideRow">
                    <button className="sideButton three x-large-font">*</button>
                    <button className="sideButton three x-large-font">**</button>
                    <button className="sideButton three x-large-font">***</button>
                </div>
            </div>
            <div>
                <h2 className="sideTitle">Szezonalitás:</h2>
                <div className="sideRow last">
                    <select className="sideSelect" />
                </div>
            </div>
        </div>
    )
}