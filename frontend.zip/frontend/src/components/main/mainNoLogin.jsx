import { useState } from "react";
import {listaz} from "../../data.js";
import Recipes from "./recipes.jsx";
import NavbarNoLogin from "../navbar/navbarNoLogin.jsx";
import Sidebar from "./sidebar.jsx";
import Footer from "../navbar/footer.jsx";

export default function MainNoLogin(){
    const [receptek, setReceptek] = useState(listaz());

    return(
        <>
        <header>
            <NavbarNoLogin />
        </header>
        <main>
            <Recipes receptek={receptek} setReceptek={setReceptek} />
            <Sidebar />
        </main>
        <footer>
            <Footer />
        </footer>
        </>
    )
}