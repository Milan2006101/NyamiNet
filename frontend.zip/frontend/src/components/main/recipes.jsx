import {listaz} from "../../data.js";
import Recipe from "./recipe.jsx";

export default function Recipes({receptek, setReceptek}){
    return(
        <section>
            <div>
                {receptek.map((recept) => (
                <Recipe
                    {...recept}
                    key={recept.receptnev}
                />
                ))}
            </div>
        </section>
    )
}