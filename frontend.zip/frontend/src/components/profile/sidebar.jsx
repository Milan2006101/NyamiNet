export default function SidebarProfile(){
    return(
        <div className="sidebar sidebar-profile">
            <div>
                <h2 className="sideTitle">Általános</h2>
                <div className="sideRow">
                </div>
            </div>
            <div>
                <h2 className="sideTitle">Saját receptek</h2>
            </div>
        </div>
    )
}