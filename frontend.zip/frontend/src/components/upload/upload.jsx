import NavbarLogin from "../navbar/navbarLogin.jsx"
import Footer from "../navbar/footer.jsx";

export default function Upload(){

    return(
        <>
        <header>
            <NavbarLogin selected={"feltoltes"}/>
        </header>
        <main>
            <div className="three uploadMargin">
                <div className="box">
                    <h1 className="title">Recept neve:</h1>
                    <input className="sideSelect" type="text"></input>
                </div>
                <div className="box">
                    <h1 className="title">Recept leírása:</h1>
                    <textarea className="sideSelect tall" type="text"></textarea>
                </div>
                <div className="box">
                    <h1 className="title">Kép:</h1>
                    <img />
                    <button className="button">Fájl kiválasztása</button>
                </div>
            </div>

            <div className="three uploadMargin">
                <div className="box">
                    <h1 className="title">Hozzávalók:</h1>
                    <div>
                        <input className="uploadInput five" type="text"></input>
                        <input className="uploadInput five" type="text"></input>
                        <input className="uploadInput five" type="text"></input>
                        <button className="deleteButton five">Törlés</button>
                    </div>
                    <div>
                        <input className="uploadInput five" type="text"></input>
                        <input className="uploadInput five" type="text"></input>
                        <input className="uploadInput five" type="text"></input>
                        <button className="deleteButton five">Törlés</button>
                    </div>
                    <div className="wrap">
                        <h2 className="subtitle">Hozzávaló hozzáadása: </h2>
                        <button className="button">+</button>
                    </div>
                </div>
                <div className="box">
                    <h1 className="title">Lépések:</h1>
                    <input className="uploadInput three" type="text"></input>
                    <button className="deleteButton five">Törlés</button>
                    <div className="wrap">
                        <h2 className="subtitle">További lépés hozzáadása: </h2>
                        <button className="button">+</button>
                    </div>
                </div>
                <button className="button">Feltöltés</button>
            </div>
            <div className="three uploadMargin">
                <div className="box">
                    <h1 className="title">Jellemzők:</h1>
                    <h2 className="subtitle">Kategória:</h2>
                    <select className="sideSelect" />

                    <h2 className="subtitle">Konyha:</h2>
                    <select className="sideSelect" />

                    <h2 className="subtitle">Ár:</h2>
                    <div>
                        <button className="sideButton five">$</button>
                        <button className="sideButton five">$$</button>
                        <button className="sideButton five">$$$</button>
                    </div>

                    <h2 className="subtitle">Adag: </h2>
                    <div>
                    <input type="number" className="sideSelect"></input>
                    </div>

                    <h2 className="subtitle">Nehézség:</h2>
                    <div>
                        <button className="sideButton five">*</button>
                        <button className="sideButton five">**</button>
                        <button className="sideButton five">***</button>
                    </div>

                    <h2 className="subtitle">Elkészítési idő:</h2>
                        <input type="number"></input> perc
                        <br />
                        <input type="number"></input> óra
                        <br />
                        <input type="number"></input> nap

                    <h2 className="subtitle">Fogás:</h2>
                    <select className="sideSelect" />
                </div>
            </div>
        </main>
        <footer className="footer">
            <Footer />
        </footer>
        </>
    )
}