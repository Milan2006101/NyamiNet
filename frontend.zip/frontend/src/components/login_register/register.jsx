import NavbarBack from "../navbar/navbarBack.jsx";
import Footer from "../navbar/footer.jsx";
import { Link, useNavigate } from "react-router-dom";

export default function Register(){
    const navigate = useNavigate();

    return(
        <>
        <header>
            <NavbarBack/>
        </header>
        <main className="center">
            <table className="loginpage">
                <tr>
                    <td className="center title">
                        <h1>Regisztráció</h1>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div className="box">

                        <h3 className="subtitle">Név:</h3>
                        <input type="text" className="inputfield"></input>

                        <h3 className="subtitle">Jelszó:</h3>
                        <input type="password" className="inputfield"></input>

                        <h3 className="subtitle">Jelszó megerősítése:</h3>
                        <input type="password" className="inputfield"></input>

                        <h3 className="subtitle">Email:</h3>
                        <input type="email" className="inputfield"></input>

                        <h3 className="subtitle">Preferenciák:</h3>
                        <select className="inputfield" />

                        <br/>

                        <button  onClick={() => navigate("/mainlogin")} className="button">Regisztráció</button>
                        
                        <Link to="/login" className="link">
                            Bejelentkezés
                        </Link>

                        </div>
                    </td>
                </tr>
            </table>
            
            
        </main>
        <footer className="footer">
            <Footer />
        </footer>
        </>
    )
}