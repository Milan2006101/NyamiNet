import NavbarBack from "../navbar/navbarBack.jsx";
import Footer from "../navbar/footer.jsx";
import { Link, useNavigate  } from "react-router-dom";

export default function Login(){
    const navigate = useNavigate();

    return(
        <>
        <header>
            <NavbarBack/>
        </header>
        <main className="center">
            <table className="loginpage">
                <tr>
                    <td className="center title">
                        <h1>Bejelentkezés</h1>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div className="box">
                        <h3 className="subtitle">Név:</h3>
                        <input type="text" className="inputfield"></input>
                        <h3 className="subtitle">Jelszó:</h3>
                        <input type="password" className="inputfield"></input>
                        <br/>
                        <button onClick={() => navigate("/mainlogin")} className="button">Bejelentkezés</button>
                        
                        
                        <Link to="/register" className="link">
                            Regisztráció
                        </Link>

                        </div>
                    </td>
                </tr>
            </table>
            
            
        </main>
        <footer className="footer">
            <Footer />
        </footer>
        </>
    )
}