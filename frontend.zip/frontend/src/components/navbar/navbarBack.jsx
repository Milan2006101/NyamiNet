import reactLogo from '../../assets/react.svg'
import { useNavigate } from "react-router-dom";



export default function NavbarBack(){
    const navigate = useNavigate();
return(
    <>
    <div className="navbar">
            <img src={reactLogo} />
            <a className="nyami feher">NyamiNet</a>
            <div className="right">
            <button onClick={() => navigate("/")} className="btn btn-large" type="submit">Vissza</button>
            </div>
    </div>
    </>
)
}

