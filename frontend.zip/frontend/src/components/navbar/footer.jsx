export default function Footer(){
return(
    <div className="navbar">
    </div>
)
}
