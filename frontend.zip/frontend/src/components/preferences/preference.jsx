export default function PREFERENCE({id,asd,dsa,a,b}){
    return(
        <div>
            
        </div>
    )
}